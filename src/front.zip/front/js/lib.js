import { DDSHeader } from "./ddsheader.js"
import { DDSFooter } from "./ddsfooter.js"

customElements.define('dds-header', DDSHeader);
customElements.define('dds-footer', DDSFooter);